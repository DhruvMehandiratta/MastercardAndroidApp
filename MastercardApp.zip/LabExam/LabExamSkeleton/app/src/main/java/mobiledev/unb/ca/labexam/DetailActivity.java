package mobiledev.unb.ca.labexam;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // TODO
        //  Get the intent that started this activity along with the extras added to it
        Intent intent = getIntent();
        String city = intent.getStringExtra("City");
        String number = intent.getStringExtra("Number");
        String dates = intent.getStringExtra("Dates");
        final String wikipediaLink = intent.getStringExtra("Wikipedia ink");
        String year = intent.getStringExtra("Year");
        // TODO
        //  Set the details for the number, year, and dates text views
        TextView textView = (TextView)findViewById(R.id.item_textview);
        textView.setText(city);
        TextView textView1 = (TextView)findViewById(R.id.number_textview);
        textView1.setText(number);
        TextView textView2 = (TextView)findViewById(R.id.dates_textview);
        textView2.setText(dates);
        TextView textView3 = (TextView)findViewById(R.id.wiki_button);
        textView3.setText(wikipediaLink);
        TextView textView4 = (TextView)findViewById(R.id.year_textview);
        textView4.setText(year);
        // TODO
        //  Set an onClickListener such that when this button is clicked, an implicit intent is started
        //  to open the wikipedia URL in a web browser. Be sure to check that there is
        //  an application installed that can handle this intent before starting it.
        //  If the intent can't be started, show a toast indicating this.
        // Hints:
        // https://developer.android.com/reference/android/content/Intent.html#resolveActivity(android.content.pm.PackageManager)
        // https://developer.android.com/guide/components/intents-common.html#Browser
        // https://developer.android.com/reference/android/net/Uri.html#parse(java.lang.String)
        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWebPage(wikipediaLink);
            }
        });
        // TODO
        //  Set the title of the action bar to be the host city name
        getSupportActionBar().setTitle(city);
    }
    public void openWebPage(String wikipediaLink){
        Uri webpage = Uri.parse(wikipediaLink);
        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
        if(intent.resolveActivity(getPackageManager())!= null){
            startActivity(intent);
        }
    }
}
