package com.example.mastercardinterview;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private String TAG = MainActivity.class.getSimpleName();
    TextView technicalText;
    String isTechnical;
    Button button;
    ArrayList<Interviewer> mInterviewers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        technicalText = (TextView) findViewById(R.id.isTechnical);
        button = (Button) findViewById(R.id.button);
        new GetContacts().execute();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, InterviewersActivity.class);
                i.putExtra("SIZE" , mInterviewers.size());
                for (int x = 0 ; x < mInterviewers.size() ; x++){
                    i.putExtra(x+"", mInterviewers.get(x).getName());
                }
                startActivity(i);
            }
        });
    }

        private class GetContacts extends AsyncTask<Void, Void, Void> {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                Toast.makeText(MainActivity.this,"Json Data is downloading"
                        ,Toast.LENGTH_LONG).show();
            }

            @Override
            protected Void doInBackground(Void... arg0) {
                HttpHandler sh = new HttpHandler();
                // Making a request to url and getting response
                //String url = "http://dummy.restapiexample.com/api/v1/employees";
                String url = "http://192.168.56.1:8080/mastercard";
                String jsonStr = sh.makeServiceCall(url);
                if(jsonStr == null){
                    Log.d("DHRUV","null json");
                }

                Log.e(TAG, "Response from url: " + jsonStr);
                if (jsonStr != null) {
                    try {
                        JSONObject jsonObj = new JSONObject(jsonStr);

                        // Getting JSON Array node

                        String id = jsonObj.getString("id");
                        Log.d("DHRUV IDDDD","DHRUVVVVVVVVVVVVVVVVVVVVV"+id);
                        String content = jsonObj.getString("content");
                        Log.d("DHRUV CONTENT","DHRUVVVVVVVVVVVVVVVVVVVVV"+content);

                        isTechnical = jsonObj.getString("technical");
                        Log.d("DHRUV technical?","DHRUVVVVVVVVVVVVVVVVVVVVV"+isTechnical);


                        JSONArray interviewers = jsonObj.getJSONArray("interviewers");
                        Log.d("DHRUV ARRAY SIZE " , "SIZE" + interviewers.length());
                        mInterviewers = new ArrayList<Interviewer>();
                        for(int i = 0 ; i < interviewers.length(); i++){
                            JSONObject interviewer = interviewers.getJSONObject(i);
                            String iName = interviewer.get("name").toString();
                            Interviewer iv = new Interviewer(iName);
                            mInterviewers.add(iv);
                            Log.d("DHRUV ARRAY ELEMENT NAME " , "SIZE" + iName);

                            //interviewer.getJSONArray("interviewee");
                        }

                    }
                    catch (final JSONException e) {
                        Log.e(TAG, "Json parsing error: " + e.getMessage());
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(),
                                        "Json parsing error: " + e.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        });

                    }

                } else {
                    Log.e(TAG, "Couldn't get json from server.");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Couldn't get json from server. Check LogCat for possible errors!",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                super.onPostExecute(result);
                if(isTechnical.equals("true")){
                    technicalText.setText("Technical Interview");
                }else{
                    technicalText.setText("Non-Tech");
                }

            }
        }
    }
