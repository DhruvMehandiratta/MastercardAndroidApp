package com.example.mastercardinterview;

public class Interviewer {
    private String name;
    private Interview[] interviews;

    public Interviewer(String name){
        this.name = name;
    }

    public Interviewer(String name, Interview[] interviews){
        this.name = name;
        this.interviews = interviews;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Interview[] getInterviews() {
        return interviews;
    }

    public void setInterviews(Interview[] interviews) {
        this.interviews = interviews;
    }
}
