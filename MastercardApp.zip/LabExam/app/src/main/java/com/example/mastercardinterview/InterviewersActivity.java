package com.example.mastercardinterview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class InterviewersActivity extends AppCompatActivity {

    private ListView mListView;
    private ArrayAdapter aAdapter;
    private ArrayList<String> interviewersNames;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interviewers);
        int size = getIntent().getIntExtra("SIZE", 0);
        Log.d("SIZEDHRUV",""+size);
        interviewersNames = new ArrayList<String>(size);
        for (int i = 0 ; i < size ; i++){
            interviewersNames.add(getIntent().getStringExtra(i+""));
            Log.d("HELLO","iiiiii"+getIntent().getStringExtra(i+""));
        }

        mListView = (ListView) findViewById(R.id.list_view);
        aAdapter = new ArrayAdapter<String>(this, R.layout.list_item, R.id.textView, interviewersNames);
        mListView.setAdapter(aAdapter);
    }
}
