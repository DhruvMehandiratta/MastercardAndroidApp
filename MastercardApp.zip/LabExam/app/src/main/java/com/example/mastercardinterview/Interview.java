package com.example.mastercardinterview;

public class Interview {
    private String interviewee;
    private String date;

    public Interview(String interviewee, String date){
        this.interviewee = interviewee;
        this.date = date;
    }
    public String getDate() {
        return date;
    }

    public String getInterviewee() {
        return interviewee;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setInterviewee(String interviewee) {
        this.interviewee = interviewee;
    }
}
